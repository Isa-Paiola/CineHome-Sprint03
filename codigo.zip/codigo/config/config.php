<?php

// Arquivo de configuração com as constantes do sistema

define('ARQUIVO_JSON', __DIR__ . '/../data/itens.json');
define('ARQUIVO_USUARIOS', __DIR__ . '/../data/usuarios.json');
define('DIARIA_FILME', 20.00);
define('DIARIA_SERIE', 5.00);
define('DIARIA_NOVELA', 2.00);
define('DIARIA_DESENHO', 5.00);